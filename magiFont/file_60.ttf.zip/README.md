# MIUI 12 Font Module

This Magisk module provides MIUI fonts for your device.

![](https://i.imgur.com/cKSrKFB.png)
 
## Requirements 
- Android 8.0+ 
- Magisk 19+ 

## Installation 
1. Flash this module in Magisk Manager. 
2. Reboot device. 
3. Enjoy! 

## Support 
- [Telegram](https://t.me/WSTxda) 

## Disclaimer 
- This module has not been tested on all versions of Android, proceed at your own risk.

Tested on:

- AOSP 10, 9, 8 
- LOS 17, 16
- Device: Xiaomi Redmi 4A (Rolex)

## Changelog 
### Version: 1.0 
- First release
